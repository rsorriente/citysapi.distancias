package com.github.rsorriente.citesapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Locale;

public interface countryrepository extends JpaRepos itory<countryrepository. Long> {
}
